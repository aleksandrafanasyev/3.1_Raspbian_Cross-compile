#include <stdio.h>

void hello(void)
{
	printf("Hello\n");
	return;
}
