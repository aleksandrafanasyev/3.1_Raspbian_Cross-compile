#pragma once

#ifndef LIBGOODBYE
#define LIBGOODBYE

extern void goodbye(void);

#endif
