#pragma once

#ifndef LIBHELLO
#define LIBHELLO

extern void hello(void);

#endif
