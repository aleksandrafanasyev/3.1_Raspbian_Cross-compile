#include "libhello.h"
#include "libgoodbye.h"

int main(void){
	hello();
	goodbye();
	return(0);
}
